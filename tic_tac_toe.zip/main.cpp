﻿#include "game.h"

int main() {
	game game;
	game.newGame();
	game.endGame();
}