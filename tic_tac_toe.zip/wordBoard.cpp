#include <iostream>
#include "wordBoard.h"

void wordBoard::genBoard() {
	// Not implemented
}

void wordBoard::setInBoard(int index, int s) {
	// Not implemented
}

int wordBoard::finish() {
	cout << "This type of game has not been implemented" << endl;
	// Not implemented
	return 0;
}